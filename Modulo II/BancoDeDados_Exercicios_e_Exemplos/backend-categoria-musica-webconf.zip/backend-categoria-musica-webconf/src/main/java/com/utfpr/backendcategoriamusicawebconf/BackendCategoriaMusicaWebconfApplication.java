package com.utfpr.backendcategoriamusicawebconf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendCategoriaMusicaWebconfApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendCategoriaMusicaWebconfApplication.class, args);
	}

}
