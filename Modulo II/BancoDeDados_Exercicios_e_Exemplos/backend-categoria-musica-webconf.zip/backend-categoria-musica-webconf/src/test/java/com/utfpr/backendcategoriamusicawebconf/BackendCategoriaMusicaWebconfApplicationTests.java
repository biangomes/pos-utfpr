package com.utfpr.backendcategoriamusicawebconf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendCategoriaMusicaWebconfApplicationTests {

	@Test
	void contextLoads() {
	}

}
