package utfpr.recuperacao.imobiliaria;

/**
 *
 * @author Beatriz Nascimento Gomes
 */
public final class Casa extends Imovel implements Verifica {
    private int vagasCarro = 0;
    private Edicula edicula = new Edicula();

    public int getVagasCarro() {
        return vagasCarro;
    }

    public void setVagasCarro(int vagasCarro) {
        this.vagasCarro = vagasCarro;
    }

    public Edicula getEdicula() {
        return edicula;
    }

    public void setEdicula(Edicula edicula) {
        this.edicula = edicula;
    }
    
    @Override
    public void validaNum() {
        if (this.getNumero() <= 100) {
            System.out.println("Numero da casa menor que 100!");
        }
    }

    @Override
    public void calcRua() {
        System.out.println("A rua tem: " + this.getRua().length());
    }

}
