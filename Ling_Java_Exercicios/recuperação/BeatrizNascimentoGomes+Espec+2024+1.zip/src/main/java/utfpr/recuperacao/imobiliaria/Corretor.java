package utfpr.recuperacao.imobiliaria;

/**
 *
 * @author Beatriz Nascimento Gomes
 */
public final class Corretor {
    private int rg = 0;
    private String nome = "";

    public int getRg() {
        return rg;
    }

    public void setRg(int rg) {
        this.rg = rg;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
}
