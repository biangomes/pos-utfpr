package utfpr.recuperacao.imobiliaria;

/**
 *
 * @author Beatriz Nascimento Gomes
 */
public interface Verifica {
    void validaNum();
}
