package utfpr.recuperacao.imobiliaria;

import utfpr.recuperacao.imobiliaria.exception.NumException;

/**
 *
 * @author Beatriz Nascimento Gomes
 */
public abstract class Imovel {
    private String rua = "";
    private int numero = 0;
    private Corretor corretor = new Corretor();

    public String getRua() {
        return rua;
    }

    public void setRua(String rua) {
        this.rua = rua;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) throws NumException {
        if (numero <= 5000) {
            this.numero = numero;
        } else {
            throw new NumException();
        }
    }

    public Corretor getCorretor() {
        if (corretor.getNome() == null) {
            corretor = new Corretor();
        }
        return corretor;
    }

    public void setCorretor(Corretor corretor) {
        this.corretor = corretor;
    }
    
    public abstract void calcRua();

}
