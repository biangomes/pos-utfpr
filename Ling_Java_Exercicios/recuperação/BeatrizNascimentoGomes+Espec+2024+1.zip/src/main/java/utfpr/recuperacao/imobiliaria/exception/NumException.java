/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utfpr.recuperacao.imobiliaria.exception;

/**
 *
 * @author Beatriz Nascimento Gomes
 */
public class NumException extends Exception {
    public NumException() {
        super();
    }
    
    public NumException(String message) {
        super(message);
    }
    
    public NumException(String message, Throwable cause) {
        super(message, cause);
    }
    
    public void impMsg() {
        System.out.println("Número maior que 5000");
    }
}
