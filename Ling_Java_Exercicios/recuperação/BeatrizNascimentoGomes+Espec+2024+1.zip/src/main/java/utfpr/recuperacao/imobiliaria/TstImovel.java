package utfpr.recuperacao.imobiliaria;

import utfpr.recuperacao.imobiliaria.exception.NumException;

/**
 *
 * @author Beatriz Nascimento Gomes
 */
public class TstImovel {
    public static void main(String[] args) {
        NumException numException = new NumException();
        Casa casa = new Casa();
        casa.getCorretor().setNome("Beatriz");
        casa.setRua("Rua Abelardo Ferreira");
        try { 
            casa.getEdicula().setNumero(10000);       
        } catch (NumException e) {
            e.impMsg();
        }
        
        System.out.println(casa.getCorretor().getNome());
        casa.calcRua();
        casa.getEdicula().validaNum();
    }
}
