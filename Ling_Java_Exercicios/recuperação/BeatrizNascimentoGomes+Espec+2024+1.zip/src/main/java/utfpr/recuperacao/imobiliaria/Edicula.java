package utfpr.recuperacao.imobiliaria;

/**
 *
 * @author Beatriz Nascimento Gomes
 */
public final class Edicula extends Imovel implements Verifica {
    private int area = 0;

    public int getArea() {
        return area;
    }

    public void setArea(int area) {
        this.area = area;
    }
    
    @Override
    public void validaNum() {
        if ((this.getNumero() % 2) != 0) {
            System.out.println("Número ímpar!");
        } 
        System.out.println("Número par!");
    }
    
    @Override
    public void calcRua() {
        System.out.println("A 1ª letra de rua é: " + this.getRua().charAt(0));
    }

}
