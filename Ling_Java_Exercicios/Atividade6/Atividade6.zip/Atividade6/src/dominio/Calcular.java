package dominio;

public interface Calcular {
    int calcular();
}
