public interface Calcular {
    int calcular();
}
